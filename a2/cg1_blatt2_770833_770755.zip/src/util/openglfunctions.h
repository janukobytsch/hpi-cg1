#pragma once

#include <QOpenGLFunctions_3_2_Core>

class OpenGLFunctions : public QOpenGLFunctions_3_2_Core
{
};

